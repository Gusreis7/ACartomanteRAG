#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET="${1:-$PWD}"
PATCH="$ROOT/nextcloud_port_8069.patch"
fail() { printf '[erro] %s\n' "$*" >&2; exit 1; }
command -v patch >/dev/null || fail 'Comando patch nao encontrado.'
[[ -f "$TARGET/docker-compose.yml" && -f "$TARGET/scripts/setup.sh" && -f "$TARGET/.gitea/workflows/deploy.yml" ]] \
  || fail 'Passe o caminho do repositorio independente NextcloudSelfHosted.'

if patch -d "$TARGET" -p1 --batch --forward --fuzz=0 --dry-run < "$PATCH" >/dev/null 2>&1; then
  patch -d "$TARGET" -p1 --batch --forward --fuzz=0 < "$PATCH" >/dev/null
  echo '[nextcloud] Porta HTTP alterada para 8069 no Compose, setup e README.'
  echo '[nextcloud] Workflow Gitea, dados, secrets e porta HTTPS 8443 preservados.'
elif patch -d "$TARGET" -p1 -R --batch --fuzz=0 --dry-run < "$PATCH" >/dev/null 2>&1; then
  echo '[nextcloud] Patch ja aplicado. Nenhuma alteracao necessaria.'
else
  fail 'Versao inesperada dos arquivos. O patch nao foi aplicado; verifique git diff.'
fi
