# Patch incremental: porta HTTP 8098 → 8069 (NextcloudSelfHosted)

**Base:** repositorio independente `NextcloudSelfHosted` com os patches de **seguranca LAN/Tailscale** e **armazenamento em `/mnt/Arquivos`** aplicados. Nao modifica `.gitea/workflows/deploy.yml`, servicos de banco/Redis, diretorios de dados, segredos ou outros projetos.

## O que muda

- `docker-compose.yml`: `127.0.0.1:8069:80` e `${NEXTCLOUD_LAN_IP}:8069:80`.
- `scripts/setup.sh`: dominios locais com a nova porta `8069` e remocao de entradas legadas `:8098` da lista de dominios carregada do bootstrap anterior. Preserva todas as senhas e as configuracoes de HTTPS `8443`.
- `README.md`: atualizacao de enderecos, comandos de teste e encaminhamento do Tailscale Serve.
- Nenhuma exposicao em `0.0.0.0` nem na interface Tailscale.

## Aplicar no notebook (repositório NextcloudSelfHosted)

```bash
unzip nextcloud_port_8069_patch.zip -d nextcloud_port_8069_patch
cd nextcloud_port_8069_patch
./apply_patch.sh ~/Projetos/Homelab/NextcloudSelfHosted
```

Antes do push, atualize o `setup.sh` no Raspberry (a execucao e idempotente e nao troca senhas):

```bash
cd ~/Projetos/Homelab/NextcloudSelfHosted
scp scripts/setup.sh gustavo@raspberrypi.local:/tmp/nextcloud-setup.sh
ssh -t gustavo@raspberrypi.local 'sudo bash /tmp/nextcloud-setup.sh'
```

Depois, deploy no mesmo workflow do Gitea:

```bash
git add docker-compose.yml scripts/setup.sh README.md
git commit -m "fix(nextcloud): change HTTP port to 8069"
git push origin main
```

## Tailscale Serve (se já estava configurado)

A porta **externa HTTPS continua 8443**; altere **somente o alvo interno** após o deploy:

```bash
sudo tailscale serve status
sudo tailscale serve --https=8443 off
sudo tailscale serve --bg --https=8443 http://127.0.0.1:8069
sudo tailscale serve status
```

**Atenção:** `--https=8443 off` desativa o handler daquela porta. Se houver **outros serviços/caminhos na mesma 8443**, confira o status e não execute o `off` sem primeiro planejar a preservacao das demais rotas. O comando de nova configuracao serve apenas para uma rota de Nextcloud na raiz `/`.

## Verificar no Raspberry

```bash
curl -I http://127.0.0.1:8069
docker ps --format 'table {{.Names}}\t{{.Ports}}' | grep -E 'nextcloud|8069'
sudo tailscale serve status
```

- LAN: `http://<IP_LAN_DO_RASPBERRY>:8069`, sem cliente Tailscale.
- Remoto: `https://server-1.<sua-tailnet>.ts.net:8443`, cliente Tailscale conectado.

O deploy no Gitea reconfigura o container; **nao rode `docker compose down -v`**. Se o Nextcloud ja estiver instalado e rejeitar a nova origem por `untrusted domain`, confira o array `trusted_domains` com `docker compose exec -u www-data app php occ config:system:get trusted_domains` e adicione o endereco com a nova porta em um indice livre. O bootstrap atualiza `app.env`, mas uma instalacao antiga pode ter dominios fixados em `config.php`.
